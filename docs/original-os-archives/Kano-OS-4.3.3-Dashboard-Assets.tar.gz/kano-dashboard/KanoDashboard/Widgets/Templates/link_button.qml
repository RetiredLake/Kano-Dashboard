/**
 * link_button.qml
 *
 * Copyright (C) 2017 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A button which looks like link text
 *
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Colours 1.0 as Colours


Templates.ButtonWidget {
    id: change_network

    text_capitalization: Font.AllUppercase
    radius: height / 2
    width: text_width
    height: text_height

    text_color: area.containsMouse ?
        Qt.darker(Colours.Palette.link_color, 1.1) :
        Colours.Palette.link_color

    color: 'transparent'
}
