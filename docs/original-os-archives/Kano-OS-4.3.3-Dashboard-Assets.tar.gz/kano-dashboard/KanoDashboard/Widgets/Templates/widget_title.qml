/**
 * widget_title.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A widget for use in titles, containing a text field and an (optional) icon
 * next to it.
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Fonts 1.0 as Fonts

Rectangle {
    property alias text: label.text
    property alias textSize: label.font.pixelSize
    property alias bold: label.font.bold
    property alias mousearea: mousearea
    property alias image: image
    property alias label: label

    property int margins: 10

    anchors.margins: 0
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 70
    color: "transparent"

    Fonts.H3 {
        id: label
        anchors.verticalCenter: parent.verticalCenter
        anchors.horizontalCenter: parent.horizontalCenter
    }

    Image {
        id: image
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        fillMode: Image.PreserveAspectFit
        anchors.rightMargin: margins
    }

    MouseArea {
        id: mousearea
        anchors.fill: parent
    }
}
