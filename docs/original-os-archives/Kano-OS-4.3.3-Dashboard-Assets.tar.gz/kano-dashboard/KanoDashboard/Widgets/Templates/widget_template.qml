/**
 * widget_template.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A base widget that (nearly) all widgets should inherit from. It adds signals
 * for showing and hiding the dashboard, button effects and launching
 * capabilities.
 */

import QtQuick 2.3
import QtQuick.Controls 1.4

import Kano.Process 1.0

import KanoDashboard.Widgets.Templates 1.0 as Templates

Rectangle {
    signal highlight(int x, int y, variant widget)  // Allows widget onboarding highlighting
    signal clicked(var mouse)  // Allow it to be treated as a button
    signal update()  // Trigger the widget to refresh its data

    // Is the widget locked out, disabled or in a loading state?
    property bool locked: false
    property bool disabled: false
    property bool loading: false

    property int widgetCount: 1  // Evenly scale a number of widgets in a fixed space

    property alias title: title
    property int spacing: 10
    property string view: ''
    property bool quit_on_run: false

    // Launch apps when clicked
    property string switch_mode: ''  // Mode name to change to (e.g. overworld/desktop)
    property string open_view: ''  // Hide the dashboard and launch the supplied command
    property var launch: []  // Raw access to the process starter

    property string hover_colour: ''
    property bool hover_sound_enabled: hover_colour != ''
    property alias area: mouse_area
    property bool activatable: (view != '') || (switch_mode != '') || (open_view != '') || (launch.length > 0)
    property string description
    property var highlight_click_widget

    id: wrapper
    color: 'transparent'

    onHighlight: {
        if (parent.highlight !== undefined) {
            parent.highlight(
                wrapper.x + x,
                wrapper.y + y,
                widget
            );
        }
    }

    states: [
        State {
            name: 'normal'
            PropertyChanges {
                target: wrapper
                z: 0
            }
        },
        State {
            name: 'highlighted'
            PropertyChanges {
                target: wrapper
                z: 200
            }
        }
    ]
    state: 'normal'

    /**
     * Require both width and height to be set before propagating
     * FIXME: Find a single signal that works
     */
    property bool size_set: false
    function originate_highlight() {
        if (!size_set) {
            size_set = true;
            return;
        }

        if (wrapper.state == 'highlighted') {
            wrapper.highlight(0, 0, wrapper);
        }
    }

    onWidthChanged: originate_highlight()
    onHeightChanged: originate_highlight()

    anchors.margins: spacing
    height: parent.height
    width: (parent.width / widgetCount) - spacing
    radius: 5

    Templates.WidgetTitle {
        id: title
    }

    Templates.RawProcess {
        id: process
    }

    Templates.SwitchModeProcess {
        id: switch_mode_proc
    }

    Templates.OpenViewProcess {
        id: open_view_proc
    }

    MouseArea {
        property string base_colour: parent.color
        function activate() {
            if (view != '') {
                app_state.change_view(view)
            }

            if (switch_mode != '') {
                Templates.ProcessLauncher.switch_mode.run(switch_mode)
            }

            if (open_view != '') {
                Templates.ProcessLauncher.open_view.run(open_view)
            }

            if (launch.length > 0) {
                // This is a click to a button that launches an X11 app
                app_state.fade_out();
                Templates.ProcessLauncher.process.start(launch[0], launch[1]);
            }

            if (activatable) {
                // This is a click to a widget within the Dashboard
                // (no app start or mode changes)
                app_state.play_click_sound();
            }
        }

        id: mouse_area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: activatable ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: {
            parent.clicked(mouse)
            activate()
        }

        onEntered: {
            if (parent.hover_sound_enabled) {
                app_state.play_hover_sound();
            }

            if (parent.hover_colour != '') {
                base_colour = parent.color
                parent.color = parent.hover_colour;
            }
        }

        onExited: {
            if (parent.hover_colour != '') {
                parent.color = base_colour;
            }
        }
    }

    Rectangle {
        id: lock_overlay
        color: '#000000'
        opacity: 0.7
        z: 100
        visible: parent.disabled || parent.locked || parent.loading
        anchors.fill: parent
    }

    Image {
        source: 'lock.png'
        anchors.centerIn: parent
        z: 100
        visible: parent.locked
    }

    BusyIndicator {
        running: parent.loading
        anchors.centerIn: parent
        z: 100
        visible: parent.loading
    }
}
