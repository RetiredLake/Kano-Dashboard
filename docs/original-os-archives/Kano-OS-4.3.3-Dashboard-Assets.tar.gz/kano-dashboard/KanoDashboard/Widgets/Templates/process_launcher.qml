/**
 * process_launcher.qml
 *
 * Copyright (C) 2018-2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Process to launch an application and Dashboard exiting afterwards.
 */

pragma Singleton

import QtQuick 2.3
import KanoDashboard.Widgets.Templates 1.0 as Templates


Item {
    property QtObject open_view: Templates.OpenViewProcess {
    }
    property QtObject switch_mode: Templates.SwitchModeProcess {
    }
    property QtObject process: Templates.RawProcess {
    }
}
