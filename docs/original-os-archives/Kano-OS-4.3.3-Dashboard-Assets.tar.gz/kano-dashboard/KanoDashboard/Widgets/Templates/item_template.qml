/**
 * item_template.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * An item widget with added signals for showing and hiding the dashboard.
 */


import QtQuick 2.3

Item {
    id: item
    property var owner: parent

    signal highlight(int x, int y, variant widget)

    onHighlight: {
        if (owner.highlight !== undefined) {
            owner.highlight(
                item.x + x,
                item.y + y,
                widget
            );
        }
    }
}
