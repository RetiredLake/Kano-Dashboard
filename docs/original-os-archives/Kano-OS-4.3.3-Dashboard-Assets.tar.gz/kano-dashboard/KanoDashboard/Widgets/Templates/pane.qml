import QtQuick 2.3
import QtQuick.Controls 1.4
import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Styles 1.0 as Styles

Rectangle {
    signal open()
    signal close()

    default property alias _contentChildren: content.contentItem
    property alias close_btn: close_btn
    property alias title: title.text
    property alias spacer_height: spacer.height
    property alias spacer_colour: spacer.color
    property int spacer_margin: 8


    id: pane

    height: parent.height

    Item {
        property int margins: 20
        id: heading

        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right

        height: Math.max(title.height, close_btn.height) + 2 * margins
        anchors.margins: margins

        Fonts.H1 {
            id: title
            anchors.verticalCenter: close_btn.verticalCenter
            anchors.left: parent.left
            verticalAlignment: Text.AlignVCenter
        }

        Templates.ButtonWidget {
            id: close_btn
            image: 'close.png'
            onClicked: pane.close()

            anchors.top: parent.top
            anchors.right: parent.right
        }

        Rectangle {
            id: spacer
            color: '#e4e4e4'
            radius: height / 2
            height: 2

            anchors.bottom: parent.bottom
            anchors.left: parent.left
            anchors.right: parent.right
        }

    }

    states: [
        State {
            name: 'open'
            PropertyChanges {
                target: pane
                visible: true
                width: 400
            }
        },
        State {
            name: 'closed'
            PropertyChanges {
                target: pane
                visible: false
                width: 0
            }
        }
    ]

    property int duration: 100
    transitions: [
        Transition {
            from: 'closed'
            to: 'open'
            SequentialAnimation {
                PropertyAnimation {
                    target: pane
                    properties: 'visible'
                    duration: 0
                }
                NumberAnimation {
                    target: pane
                    properties: 'width'
                    duration: duration
                }
            }
        },
        Transition {
            from: 'open'
            to: 'closed'
            SequentialAnimation {
                NumberAnimation {
                    target: pane
                    properties: 'width'
                    duration: duration
                }
                PropertyAnimation {
                    target: pane
                    properties: 'visible'
                    duration: 0
                }
            }
        }
    ]

    state: 'closed'

    onOpen: state = 'open'
    onClose: state = 'closed'

    ScrollView {
        id: content

        anchors.topMargin: spacer_margin
        anchors.bottomMargin: notif_menu.spacing

        anchors.top: heading.bottom
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right

        style: Styles.ScrollStyle {}
    }
}
