/**
 * round_button.qml
 *
 * Copyright (C) 2017 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A rounded button
 *
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates


Templates.ButtonWidget {
    id: change_network

    text_capitalization: Font.AllUppercase
    radius: height / 2
    width: text_width + height
}
