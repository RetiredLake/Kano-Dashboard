/**
 * menu_widget.qml
 *
 * Copyright (C) 2016-2017 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget which has states for opening and closing intended for use as pop-up
 * menus.
 */



import QtQuick 2.3

import KanoDashboard.Widgets.PowerMenu 1.0 as PowerMenu
import KanoDashboard.Widgets.Templates 1.0 as Templates


Templates.WidgetTemplate {
    property point global_pos
    property var owner
    property point offset: Qt.point((menu.width - owner.width) / 2, 0)
    property int separation: 4
    property bool inited: false

    id: menu
    z: 100

    MouseArea {
        x: -global_pos.x
        y: -global_pos.y
        width: app_state.global_scope.width
        height: app_state.global_scope.height
        onClicked: {
            var x = mouse.x - global_pos.x;
            var y = mouse.y - global_pos.y;

            if (x > 0 && x < menu.width
                    && y > 0 && y < menu.height) {
                return true;
            }

            close();
        }
    }

    function register() {
        function connect() {
            var scope = app_state.global_scope,
                items = [],
                i;

            for (i = 0; i < scope.menus.length; i++) {
                items.push(scope.menus[i]);
            }

            items.push(menu);
            scope.menus = items;
        }

        if (app_state.global_scope) {
            connect();
        } else {
            app_state.global_scope_changed.connect(connect);
        }
    }

    Component.onCompleted: menu.register()

    function position_menu() {
        var owner_pos;

        if (!owner) {
            return;
        }

        owner_pos = owner.mapToItem(null, 0, 0);

        menu.x = owner_pos.x - offset.x;
        menu.y = owner_pos.y - menu.height - offset.y - separation;
        global_pos = Qt.point(menu.x, menu.y);
    }

    states: [
        State {
            name: 'shown'
            StateChangeScript {
                script: {

                    if (!inited) {
                        position_menu()
                        inited = true;
                    }
                }
            }
            PropertyChanges {
                target: menu
                visible: true
            }
        },
        State {
            name: 'hidden'
            PropertyChanges {
                target: menu
                visible: false
            }
        }
    ]
    state: 'hidden'

    function open() {
        menu.state = 'shown';
    }

    function close() {
        menu.state = 'hidden';
    }

    function toggle_state() {
        if (menu.state == 'hidden') {
            menu.open();
        } else {
            menu.close();
        }
    }
}
