/**
 * open_view_process.qml
 *
 * Copyright (C) 2016-2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Process to launch an application and Dashboard minimising.
 */

import Kano.Process 1.0


Process {
    id: open_view_proc
    function run(app) {
        app_state.play_open_sound();
        app_state.fade_out();
        kano_profile.track_data(
            'kanoDashboard-appLaunch',
            '{ "appName": "' + app + '"}'
        );
        open_view_proc.start(
            'kano-dashboard-xapp', [app]
        );
    }
    onFinished: {
        app_state.fade_in();
    }
}
