import Kano.Process 1.0


Process {
    id: process
    onFinished: {
        if (quit_on_run) {
            Qt.quit();
        } else {
            app_state.fade_in();
        }
    }
}
