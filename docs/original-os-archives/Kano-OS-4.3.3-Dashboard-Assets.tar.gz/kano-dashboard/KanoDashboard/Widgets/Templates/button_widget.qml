/**
 * button_widget.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A widget used for buttons
 */


import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours

Templates.WidgetTemplate {
    property alias text: text.text
    property alias text_width: text.width
    property alias text_height: text.height
    property alias text_color: text.color
    property alias text_capitalization: text.font.capitalization
    property alias fontSize: text.font.pixelSize
    property alias image: img.source
    property alias image_overlay: img.overlay
    property color image_color: Colours.Palette.dark_color
    property int padding: 15

    color: area.containsMouse ?
        Colours.Palette.dark_color : Colours.Palette.button_color

    height: Math.max(text.height, img.height) + 2 * padding
    width: Math.max(text.width + 2 * radius, img.width + 2 * padding)
    radius: height / 2
    activatable: true
    area.z: 100
    hover_sound_enabled: true

    Fonts.H3 {
        id: text
        anchors.centerIn: parent
        color: parent.area.containsMouse ?
            Colours.Palette.button_text_color : Colours.Palette.dark_color
    }

    Templates.ImageWidget {
        id: img
        height: text.height * 1.5
        width: height
        anchors.centerIn: parent
        overlay.color: parent.area.containsMouse ?
            'transparent' : image_color
    }
}
