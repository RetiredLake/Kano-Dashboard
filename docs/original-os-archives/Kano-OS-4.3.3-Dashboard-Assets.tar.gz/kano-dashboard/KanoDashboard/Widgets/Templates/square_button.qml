import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.ButtonWidget {
    radius: 3
}
