/**
 * content_widget.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A base class for widgets which will populate them main portion of the home
 * screen.
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.WidgetTemplate {
    property int guide_height: height
    property int max_width
}
