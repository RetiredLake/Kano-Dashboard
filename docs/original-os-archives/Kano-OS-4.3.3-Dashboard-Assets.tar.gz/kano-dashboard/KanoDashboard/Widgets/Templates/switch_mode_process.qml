/**
 * switch_mode_process.qml
 *
 * Copyright (C) 2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Process to launch an application and Dashboard exiting afterwards.
 */

import QtQuick 2.3


Item {
    id: root

    function run(cmd) {
        root.run_app(cmd, {});
    }

    function run_app(cmd, app_data) {
        app_state.play_open_sound();
        kano_profile.track_data(
            'kanoDashboard-appLaunch',
            '{ "appName": "' + cmd + '"}'
        );
        if (app_data.single_app_mode) {
            app_state.supervisor_app_launch(cmd, '/tmp/dashtest-single-app-mode');
        } else {
            app_state.supervisor_app_launch('', '/tmp/dashtest-' + cmd);
        }

        app_state.fade_out();
        Qt.quit();
    }
}
