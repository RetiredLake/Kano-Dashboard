/**
 * status_widget.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A status icon template
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Status 1.0 as Status
import KanoDashboard.Widgets.Colours 1.0 as Colours

Templates.ButtonWidget {
    property bool toggle_disabled: false
    property bool inited: false
    property var menu

    id: icon

    onClicked: {
        if (toggle_disabled) {
            return true;
        }

        menu.toggle_state();
    }

    color: menu.state == 'shown' || area.containsMouse ?
        Colours.Palette.dark_color : Colours.Palette.button_color
    image_overlay.color: menu.state == 'shown' || area.containsMouse ?
        'transparent' : image_color
    activatable: true

    onUpdate: menu.refresh()
    Component.onCompleted: {
        menu.owner = icon;
        menu.refresh();
    }
}
