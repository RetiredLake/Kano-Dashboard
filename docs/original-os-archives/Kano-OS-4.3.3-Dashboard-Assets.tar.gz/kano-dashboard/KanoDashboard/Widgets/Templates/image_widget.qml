/**
 * image_widget.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * An image widget with added signals for showing and hiding the dashboard.
 * Also adds corner rounding and overlay effects.
 */


import QtQuick 2.3
import KanoDashboard.Widgets.Templates 1.0 as Templates
import QtGraphicalEffects 1.0

Templates.WidgetTemplate {
    property alias img: img
    property alias source: img.source
    property alias fillMode: img.fillMode
    property alias overlay: overlay

    property int radius: 0
    property string default_source: ''
    property int padding: 0

    id: wrapper
    height: width

    Image {
        id: img
        anchors.fill: parent
        anchors.margins: padding
        fillMode: Image.PreserveAspectFit
        onStatusChanged: {
            if (status == Image.Error) {
                source = wrapper.default_source;
            }
        }
        visible: false
    }

    ColorOverlay {
        id: overlay
        anchors.fill: img
        source: img
        visible: false
    }

    Rectangle {
        id: mask
        radius: wrapper.radius
        anchors.fill: img
        visible: false
    }

    OpacityMask {
        anchors.fill: overlay
        source: overlay
        maskSource: mask
    }
}
