/**
 * footer_widget.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A base class for widgets which will populate the footer of the home screen
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.WidgetTemplate {
    title.textSize: 20
    title.image.width: 90
    title.image.anchors.rightMargin: -10
    title.image.fillMode: Image.PreserveAspectCrop
    height: title.height
    clip: true
}
