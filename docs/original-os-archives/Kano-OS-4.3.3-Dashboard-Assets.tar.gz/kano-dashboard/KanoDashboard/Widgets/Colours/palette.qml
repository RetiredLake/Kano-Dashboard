/*
 * palette.qml
 *
 * Copyright (C) 2016-2017 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Palette of colours to use in the system
 *
 */

pragma Singleton
import QtQuick 2.0

QtObject {
    property color bg_color: '#eef0f0'
    property color button_color: 'transparent'
    property color button_activated_color: '#cfd4d4'
    property color button_text_color: '#ffffff'
    property color dark_color: '#455054'
    property color light_color: '#99a0a2'
    property color link_color: '#ff6900'
    property color notification_color: '#f26d5b'
    property color progress_color: '#f1cb44'
    property color alert_color: '#f63636'
}
