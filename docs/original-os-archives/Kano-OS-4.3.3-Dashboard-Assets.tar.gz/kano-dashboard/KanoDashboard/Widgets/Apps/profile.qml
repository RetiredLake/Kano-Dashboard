/**
 * profile.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget for launching profile
 */


import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.FooterWidget {
    widgetCount: 6
    title.text: qsTr("Profile")
    title.bold: true
    color: '#ff6600'
    hover_colour: '#ff7b00'
    title.image.source: 'profile.png'
    open_view: 'kano-profile-gui'
}
