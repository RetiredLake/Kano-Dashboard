/**
 * youtube.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget for launching YouTube
 */


import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.FooterWidget {
    widgetCount: 6
    title.text: qsTr("YouTube")
    title.bold: true
    color: '#ec5352'
    hover_colour: '#fa5757'
    title.image.source: 'youtube.png'
    open_view: 'kano-video-browser'
}
