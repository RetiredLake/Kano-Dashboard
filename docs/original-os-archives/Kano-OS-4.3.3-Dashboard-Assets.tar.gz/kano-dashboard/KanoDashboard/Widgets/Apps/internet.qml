/**
 * internet.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget for launching a web browser
 */


import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.FooterWidget {
    widgetCount: 6
    title.text: qsTr("Internet")
    title.bold: true
    color: '#3c87d2'
    hover_colour: '#408fde'
    title.image.source: 'internet.png'
    open_view: 'kano-internet'
}
