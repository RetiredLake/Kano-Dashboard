/**
 * settings.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget for launching settings
 */


import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.ButtonWidget {
    image: 'settings.png'
    open_view: 'sudo kano-settings'
}
