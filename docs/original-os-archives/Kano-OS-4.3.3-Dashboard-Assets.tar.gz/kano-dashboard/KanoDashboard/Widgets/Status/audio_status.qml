/**
 * audio_status.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A status icon in the footer for the audio volume
 */

import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Status 1.0 as Status


Templates.StatusWidget {
    property real mute_threshold: 0.01
    property real low_threshold: 0.4
    property real high_threshold: 0.8

    id: button
    menu: Status.AudioMenu {
        id: audio_menu
        width: button.width / 2
    }

    states: [
        State {
            name: 'muted'
            when: audio_menu.volume <= mute_threshold
            PropertyChanges {
                target: button
                image: 'muted.png'
            }
        },
        State {
            name: 'unmuted'
        },
        State {
            name: 'low_vol'
            extend: 'unmuted'
            when: audio_menu.volume > mute_threshold && audio_menu.volume <= low_threshold
            PropertyChanges {
                target: button
                image: 'low_volume.png'
            }
        },
        State {
            name: 'med_vol'
            extend: 'unmuted'
            when: audio_menu.volume > low_threshold && audio_menu.volume <= high_threshold
            PropertyChanges {
                target: button
                image: 'medium_volume.png'
            }
        },
        State {
            name: 'high_vol'
            extend: 'unmuted'
            when: audio_menu.volume > high_threshold
            PropertyChanges {
                target: button
                image: 'high_volume.png'
            }
        }
    ]
}
