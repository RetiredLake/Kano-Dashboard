/**
 * audio_menu.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A menu showing the dtails of the WiFi connection, launched by the WiFi
 * status icon.
 */


import QtQuick 2.3
import QtQuick.Controls 1.4
import QtQuick.Controls.Styles 1.4

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours
import KanoDashboard.Widgets.Styles 1.0 as Styles
import KanoDashboard.Widgets.Shapes 1.0 as Shapes

Templates.MenuWidget {
    property real volume: slider.value

    width: menu.width
    height: menu.height + arrow.height

    function refresh() {
        kano_audio.update_volume();
    }

    function update_value() {
        slider.value = kano_audio.volume;
    }

    Component.onCompleted: {
        kano_audio.volume_changed.connect(update_value);
        refresh();
    }

    Rectangle {
        id: menu
        height: 230
        width: parent.width
        anchors.margins: 0
        color: Colours.Palette.dark_color
        radius: width / 2


        Slider {
            id: slider
            value: volume;
            orientation: Qt.Vertical
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.horizontalCenterOffset: -1
            anchors.topMargin: menu.radius
            anchors.bottomMargin: menu.radius
            onPressedChanged: {
                if (pressed) {
                    return;
                }

                kano_audio.set_volume(Math.round(volume * 100));
            }

            style: Styles.SliderStyle {}
        }
    }

    Shapes.Triangle {
        id: arrow
        anchors.top: menu.bottom
        anchors.topMargin: -5
        width: 25
        height: 15
        x: (parent.width - width) / 2
        color: Colours.Palette.dark_color
    }
}
