/**
 * time.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A widget for showing the time
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts

Templates.WidgetTemplate {
    width: current_time.width
    height: current_time.height

    Fonts.KanoText {
        id: current_time
        font.pixelSize: 25
        font.bold: true
    }

    function update_time() {
        current_time.text = qsTr("%1").arg(
            new Date().toLocaleTimeString(Qt.locale(), 'hh:mm')
        );
    }

    Component.onCompleted: update_time()

    Timer {
        interval: 1000
        repeat: true
        running: true

        onTriggered: update_time()
    }
}
