/**
 * wifi_status.qml
 *
 * Copyright (C) 2016-2017 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A status icon in the footer for the wifi connection.
 */


import QtQuick 2.3
import QtQml 2.2

import KanoDashboard.Widgets.Shapes 1.0 as Shapes
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours
import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Status 1.0 as Status


Templates.StatusWidget {
    property int low_threshold: 45
    property int medium_threshold: 60
    property int high_threshold: 80
    id: button
    menu: Status.WiFiDetails {
        id: details
        low_signal_mode: button.state == 'low_signal'
    }


    states: [
        State {
            name: 'default'
            PropertyChanges {
                target: button
                image_color: Colours.Palette.dark_color
            }
        },
        State {
            name: 'internet'
            extend: 'default'
            PropertyChanges {
                target: button
                open_view: ''
                toggle_disabled: false;
            }
        },
        State {
            name: 'low_signal'
            extend: 'internet'
            when: kano_networking.internet_available &&
                kano_networking.signal_strength <= low_threshold
            PropertyChanges {
                target: button
                image: 'low_signal.png'
                image_color: Colours.Palette.alert_color
            }
        },
        State {
            name: 'medium_low_signal'
            extend: 'internet'
            when: kano_networking.internet_available &&
                kano_networking.signal_strength > low_threshold &&
                kano_networking.signal_strength <= medium_threshold
            PropertyChanges {
                target: button
                image: 'medium_low_signal.png'
            }
        },
        State {
            name: 'medium_high_signal'
            extend: 'internet'
            when: kano_networking.internet_available &&
                kano_networking.signal_strength > medium_threshold &&
                kano_networking.signal_strength <= high_threshold
            PropertyChanges {
                target: button
                image: 'medium_high_signal.png'
            }
        },
        State {
            name: 'high_signal'
            extend: 'internet'
            when: kano_networking.internet_available &&
                kano_networking.signal_strength > high_threshold
            PropertyChanges {
                target: button
                image: 'high_signal.png'
            }
        },
        State {
            name: 'no_internet'
            extend: 'default'
            when: !kano_networking.internet_available
            StateChangeScript {
                script: details.close();
            }
            PropertyChanges {
                target: button
                image: 'no_internet.png'
            }
            PropertyChanges {
                target: button
                toggle_disabled: false;
                activatable: true
                open_view: 'sudo kano-wifi-gui'
            }
        }
    ]

    Timer {
        property bool updates_enabled: true

        id: signal_updater
        running: updates_enabled && kano_networking.internet_available
        interval: 3000  // msec
        repeat: true
        triggeredOnStart: true
        onTriggered: kano_networking.update_signal_strength()
    }

    Connections {
        target: app_state
        onFade_in: signal_updater.updates_enabled = true
        onFade_out: signal_updater.updates_enabled = false
    }

    Component.onCompleted: {
        app_state.refresh.connect(kano_networking.refresh);
    }
}
