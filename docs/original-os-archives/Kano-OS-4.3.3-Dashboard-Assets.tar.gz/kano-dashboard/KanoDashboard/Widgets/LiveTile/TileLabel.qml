/**
 * TileLabel.qml
 *
 * Copyright (C) 2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 *
 */


import QtQuick 2.3

import Kano.Fonts 1.0 as KanoFonts
import Kano.Components 1.0 as Components
import Kano.Colors 1.0 as Colors

import KanoDashboard.Widgets.LatestView 1.0
import KanoDashboard.Widgets.LiveTile 1.0
import KanoDashboard.Widgets.LiveTile.QTile 1.0


Item {
    property QTile tile: QTile {}

    Components.BaseImage {
        id: avatar

        // FIXME: Load actual avatar
        source: 'judoka.png'

        padding: 5
        width: height
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    Item {
        id: label

        height: title.height + username.height
        anchors.verticalCenter: parent.verticalCenter
        anchors.left: avatar.right
        anchors.right: parent.right

        KanoFonts.H3 {
            id: title
            text: tile.title
            color: Colors.KanoPalette.kano_black
            lineHeight: 1.2
            maximumLineCount: 1
            elide: Text.ElideLeft

            anchors.left: parent.left
            anchors.right: parent.right
        }
        KanoFonts.H4 {
            id: username
            text: tile.username
            color: Colors.KanoPalette.kano_dark_grey
            lineHeight: 1.2
            maximumLineCount: 1
            elide: Text.ElideRight

            anchors.top: title.bottom
            anchors.left: parent.left
            anchors.right: parent.right
        }
    }
}
