/**
 * TileCard.qml
 *
 * Copyright (C) 2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 *
 */


import QtQuick 2.3

import Kano.Fonts 1.0 as KanoFonts
import Kano.Components 1.0 as Components

import KanoDashboard.Widgets.LatestView 1.0
import KanoDashboard.Widgets.LiveTile 1.0
import KanoDashboard.Widgets.LiveTile.QTile 1.0


Components.BaseButton {
    signal selected(QTile tile)

    property QTile tile: QTile {}
    property bool horizontal: true

    radius: 5

    states: [
        State {
            name: 'horizontal'
            when: card.horizontal
            PropertyChanges {
                target: tileLabel
                anchors.left: img.right
                anchors.top: card.top
            }
            PropertyChanges {
                target: img
                anchors.bottom: card.bottom
            }
        },
        State {
            name: 'vertical'
            when: !card.horizontal
            PropertyChanges {
                target: tileLabel
                anchors.top: img.bottom
                anchors.left: card.left
            }
            PropertyChanges {
                target: img
                anchors.right: card.right
            }
        }
    ]

    id: card
    onClicked: card.selected(tile)

    height: 100
    width: 200

    AnimatedImage {
        id: img
        source: tile.coverPath

        anchors.top: parent.top
        anchors.left: parent.left
    }

    TileLabel {
        id: tileLabel
        tile: card.tile
        anchors.right: parent.right
        anchors.bottom: card.bottom
    }

    Loader {
        z: 10
        anchors.fill: parent
        sourceComponent: card.hovered ? hover_overlay : null
    }

    Component {
        id: hover_overlay
        Item {
            Rectangle {
                anchors.fill: parent

                color: 'black'
                opacity: 0.7
                radius: card.radius
            }

            KanoFonts.H3 {
                id: title
                text: card.tile.title
                color: 'white'
                lineHeight: 1.2
                maximumLineCount: 1
                elide: Text.ElideLeft

                anchors.margins: 10
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
            }
            KanoFonts.H4 {
                id: username
                text: card.tile.description
                color: 'white'
                lineHeight: 1.2
                elide: Text.ElideRight

                anchors.margins: 10
                anchors.top: title.bottom
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
            }
        }
    }
}
