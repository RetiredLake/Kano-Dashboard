/**
 * Tile.qml
 *
 * Copyright (C) 2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 *
 */


import QtQuick 2.3

import Kano.Components 1.0 as Components

import KanoDashboard.Widgets.LatestView 1.0
import KanoDashboard.Widgets.LiveTile 1.0
import KanoDashboard.Widgets.LiveTile.QTile 1.0


Components.Tile {
    signal selected(QTile tile)
    property QTile tile: QTile {}

    id: root

    image_source: tile.coverPath
    onClicked: root.selected(tile)
}
