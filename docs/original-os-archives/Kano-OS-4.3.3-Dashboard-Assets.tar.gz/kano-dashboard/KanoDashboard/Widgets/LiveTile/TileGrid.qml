/**
 * TileGrid.qml
 *
 * Copyright (C) 2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 *
 */


import QtQuick 2.3
import QtQml.Models 2.2

import Kano.Layouts 1.0

import KanoDashboard.Widgets.LiveTile 1.0
import KanoDashboard.Widgets.LiveTile.QTile 1.0
import KanoDashboard.Widgets.LiveTile.QTileList 1.0


TileGridLayout {
    signal tileClicked(QTile tile)
    property alias layout: visualModel.parts

    // TODO: Rename to ShareModel?
    property QTileList tileList: QTileList {}

    id: gridView

    model: visualModel.parts.verticalCard
    spacing: 20

    Connections {
        target: delegate
        onSelected: gridView.tileClicked(tile)
    }

    DelegateModel {
        id: visualModel
        model: tileList.tiles.slice(offset, tile_count + offset)
        delegate: Package {
            Item {
                Package.name: 'horizontalCard'
                TileCard {
                    horizontal: true
                    tile: modelData
                    onSelected: gridView.tileClicked(tile)
                    height: gridView.content_height
                    width: gridView.content_width
                    x: spacing / 2
                }
            }
            Item {
                Package.name: 'verticalCard'
                TileCard {
                    horizontal: false
                    tile: modelData
                    onSelected: gridView.tileClicked(tile)
                    height: gridView.content_height
                    width: gridView.content_width
                    x: spacing / 2
                }
            }
            Item {
                Package.name: 'tile'
                Tile {
                    tile: modelData
                    onSelected: gridView.tileClicked(tile)
                    height: gridView.content_height
                    width: gridView.content_width
                    x: spacing / 2
                }
            }
        }
    }
}
