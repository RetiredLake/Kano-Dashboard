/**
 * power_button.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A button which opens and closes the power options menu
 */


import QtQuick 2.3
import QtQuick.Controls 1.3

import KanoDashboard.Widgets.PowerMenu 1.0 as PowerMenu
import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Colours 1.0 as Colours

Templates.ButtonWidget {
    id: button
    image: 'power.png'

    color: menu.state == 'shown' || area.containsMouse ?
        Colours.Palette.dark_color : Colours.Palette.button_color
    image_overlay.color: menu.state == 'shown' || area.containsMouse ?
        'transparent' : Colours.Palette.dark_color

    property var menu: PowerMenu.PowerMenu {
        owner: button
        offset: Qt.point(0, 0)
    }

    onClicked: {
        app_state.play_click_sound();
        menu.toggle_state();
    }
}
