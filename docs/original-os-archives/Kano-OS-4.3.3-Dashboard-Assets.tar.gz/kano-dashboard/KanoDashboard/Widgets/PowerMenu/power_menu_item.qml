/**
 * menu_item.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A entry in the power menu
 */


import QtQuick 2.3
import QtQuick.Controls 1.3

import Kano.Process 1.0

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours

Item {
    id: menu_item
    signal close_menu()
    property var name: ''
    property string label: ''
    property bool show_spacer: true

    height: 65
    width: parent.width

    Templates.WidgetTemplate {
        id: item
        color: Colours.Palette.dark_color
        hover_colour: Qt.lighter(color)
        radius: 0

        width: parent.width
        anchors.top: parent.top
        anchors.bottom: spacer.top

        anchors.leftMargin: 0
        anchors.topMargin: 5
        anchors.bottomMargin: 5
        anchors.left: spacer.left

        switch_mode: name
        activatable: true
        onClicked: {
            if (!switch_mode) {
                parent.close_menu();
            }
        }

        Fonts.H3 {
            text: qsTr(label)
            verticalAlignment: Text.AlignVCenter
            color: '#ffffff'
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            anchors.left: parent.left
            anchors.leftMargin: 10
        }
    }

    Rectangle {
        id: spacer
        height: 1
        visible: menu_item.show_spacer
        width: parent.width
        anchors.bottom: parent.bottom
        anchors.left: item.left
        color: Colours.Palette.light_color
    }
}
