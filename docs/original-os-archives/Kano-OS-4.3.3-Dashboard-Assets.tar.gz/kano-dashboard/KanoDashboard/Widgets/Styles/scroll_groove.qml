import QtQuick 2.3


Rectangle {
    width: 5
    height: 5
    anchors.horizontalCenter: parent.horizontalCenter
    color: '#181818'
    radius: 3
}
