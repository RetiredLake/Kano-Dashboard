import QtQuick 2.3
import QtQuick.Controls.Styles 1.4

import KanoDashboard.Widgets.Styles 1.0 as Styles


ScrollViewStyle {
    property int bar_margin: 10
    property int handle_width: 8

    padding.right: -bar_margin

    scrollBarBackground: Item {
        width: 2 * bar_margin + handle_width
    }

    handle: Styles.ScrollHandle {
        implicitWidth: handle_width
        id: handle
        color: styleData.hovered ?
            '#979797' : '#c7cbce'
    }

    incrementControl: Item {}
    decrementControl: Item {}
}
