import QtQuick 2.3
import QtQuick.Controls.Styles 1.4

import KanoDashboard.Widgets.Styles 1.0 as Styles


SliderStyle {
    groove: Styles.ScrollGroove {}
    handle: Styles.ScrollHandle {}
}
