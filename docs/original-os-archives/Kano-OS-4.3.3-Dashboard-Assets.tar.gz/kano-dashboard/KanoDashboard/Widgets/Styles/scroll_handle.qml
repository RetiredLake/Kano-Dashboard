import QtQuick 2.3


Rectangle {
    anchors.centerIn: parent
    color: '#979797'
    implicitWidth: 20
    implicitHeight: 20
    radius: implicitWidth / 2
}
