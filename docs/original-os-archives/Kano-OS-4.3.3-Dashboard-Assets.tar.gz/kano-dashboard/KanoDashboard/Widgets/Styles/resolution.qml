pragma Singleton
import QtQuick 2.3
import QtQuick.Window 2.2

Item {
    property string low: 'low'
    property string medium: 'medium'
    property string high: 'high'
    property string resolution: Screen.width <= 1200 ? low :
        (Screen.height <= 1600 ? medium : high)
}
