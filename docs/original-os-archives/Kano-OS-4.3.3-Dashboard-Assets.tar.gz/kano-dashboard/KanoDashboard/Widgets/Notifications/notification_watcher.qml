pragma Singleton
import Notifications 1.0

Notifications {
}
