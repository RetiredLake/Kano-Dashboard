import KanoDashboard.Widgets.Notifications 1.0 as Notifications
import KanoDashboard.Widgets.Templates 1.0 as Templates


Notifications.NotificationsIndicator {
    radius: height / 2
}
