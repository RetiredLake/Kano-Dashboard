/**
 * notifications_indicator.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget to indicate if there are any (and how many) unread notifications.
 */


import QtQuick 2.3
import Notifications 1.0

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Notifications 1.0 as DashboardNotifications
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours

Templates.WidgetTemplate {
    signal new_notification(var new_notification)
    signal open()
    signal close()

    id: notifications_indicator
    width: height
    area.z: 100

    Templates.ImageWidget {
        id: icon
        anchors.fill: parent
        anchors.margins: 5
    }

    Templates.WidgetTemplate {
        id: notif_count
        color: '#ffffff'

        Fonts.H5 {
            id: notif_count_text
            text: menu.length
            color: notif_count.border.color
            anchors.centerIn: parent
            anchors.margins: 10
        }

        height: notif_count_text.height + 10
        width: notif_count_text.width + 10
        anchors.top: icon.top
        anchors.right: icon.right
        anchors.margins: 5
        border.color: '#ff524b'
        border.width: 2

        activatable: notifications_indicator.activatable
        area.propagateComposedEvents: true
        onClicked: mouse.accepted = false
        area.hoverEnabled: false
    }


    states: [
        State {
            name: 'no-notifications'
            PropertyChanges {
                target: notifications_indicator
                color: Colours.Palette.button_color
                activatable: false
            }
            PropertyChanges {
                target: icon
                source: 'alerts_empty.png'
                overlay.color: Colours.Palette.dark_color
            }
            PropertyChanges {
                target: notif_count
                visible: false
            }
        },
        State {
            name: 'notifications'
            PropertyChanges {
                target: notifications_indicator
                color: '#ff524b'
                hover_colour: '#ff7470'
                activatable: true
            }
            PropertyChanges {
                target: icon
                source: 'alerts.png'
                overlay.color: 'transparent'
            }
            PropertyChanges {
                target: notif_count
                visible: true
            }
        },
        State {
            name: 'notifications-open'
            extend: 'notifications'
            PropertyChanges {
                target: icon
                source: 'alerts_close.png'
                anchors.margins: 15
            }
            PropertyChanges {
                target: notif_count
                visible: false
            }
        }
    ]
    state: menu.state == 'shown' ? 'notifications-open' :
                (menu.length > 0 ?
                        'notifications' : 'no-notifications')

    property var menu: DashboardNotifications.NotificationWatcher.notifications

    onClicked: {
        if (state == 'no-notifications') {
            return;
        }

        if (state == 'notifications-open') {
            app_state.close_notification_list();
        } else {
            app_state.open_notification_list();
        }
    }
}
