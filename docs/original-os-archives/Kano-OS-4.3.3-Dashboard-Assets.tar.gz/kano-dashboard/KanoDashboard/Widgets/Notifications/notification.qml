/**
 * notification.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * An individual notification
 */


import QtQuick 2.3
import QNotification 1.0

import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.WidgetTemplate {
    property QNotification notification: QNotification {
    }

    height: 100
    color: '#ffffff'
    radius: 5

    Image {
        id: image
        source: notification.image_path || 'default_notification.png'
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        fillMode: Image.PreserveAspectFit
    }

    Templates.WidgetTemplate {
        height: title.height + byline.height + byline.anchors.topMargin
        anchors.verticalCenter: parent.verticalCenter
        anchors.left: image.right
        anchors.right: parent.right
        anchors.margins: 20
        open_view: notification.command

        Fonts.H2 {
            id: title
            text: notification.title
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
        }

        Fonts.H3 {
            id: byline
            text: notification.byline
            anchors.top: title.bottom
            anchors.left: parent.left
            anchors.right: parent.right
        }
    }

    Templates.ButtonWidget {
        id: button_1
        visible: notification.button_1_required
        text: notification.button_1_label
        color: notification.button_1_colour || '#486879'
        hover_colour: notification.button_1_hover || '#4e7285'
        open_view: notification.button_1_command
        anchors.right: parent.right
        anchors.top: parent.top
        height: parent.height / 2
        width: 80
        fontSize: 12
        anchors.margins: 0
    }

    Templates.ButtonWidget {
        id: button_2
        visible: notification.button_2_required
        text: notification.button_2_label
        color: notification.button_2_colour || '#486879'
        hover_colour: notification.button_2_hover || '#4e7285'
        open_view: notification.button_2_command
        anchors.top: button_1.bottom
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: parent.height / 2
        width: 80
        fontSize: 12
        anchors.margins: 0
    }
}
