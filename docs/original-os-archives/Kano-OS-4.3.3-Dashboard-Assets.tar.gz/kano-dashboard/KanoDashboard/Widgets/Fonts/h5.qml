import KanoDashboard.Widgets.Styles 1.0 as Styles
import KanoDashboard.Widgets.Fonts 1.0 as Fonts

Fonts.KanoText {
    large_size: 14
    medium_size: 12
    small_size: 10
}
