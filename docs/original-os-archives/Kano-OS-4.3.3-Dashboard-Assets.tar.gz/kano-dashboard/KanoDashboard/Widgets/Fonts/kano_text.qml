/**
 * kano_text.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A base text class to keep the fonts uniform among all widgets.
 */


import QtQuick 2.0
import KanoDashboard.Widgets.Styles 1.0 as Styles
import KanoDashboard.Widgets.Colours 1.0 as Colours


Text {
    property int small_size: 14
    property int medium_size: 18
    property int large_size: 18

    color: Colours.Palette.dark_color
    font.family: 'Bariol'
    font.pixelSize: Styles.Resolution.resolution == Styles.Resolution.low ? small_size :
        (Styles.Resolution.resolution == Styles.Resolution.medium ? medium_size : large_size)
    wrapMode: Text.Wrap
}
