import KanoDashboard.Widgets.Fonts 1.0 as Fonts

Fonts.KanoText {
    large_size: 30
    medium_size: 24
    small_size: 18
    font.bold: true
}
