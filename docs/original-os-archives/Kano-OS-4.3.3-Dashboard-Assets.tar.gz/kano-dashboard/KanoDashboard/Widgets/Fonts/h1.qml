import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours

Fonts.KanoText {
    large_size: 36
    medium_size: 30
    small_size: 26
    font.bold: true
}
