import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours

Fonts.KanoText {
    large_size: 22
    medium_size: 18
    small_size: 14
    font.bold: true
}
