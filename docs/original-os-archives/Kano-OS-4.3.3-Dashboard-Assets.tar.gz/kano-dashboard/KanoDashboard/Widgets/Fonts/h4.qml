import KanoDashboard.Widgets.Styles 1.0 as Styles
import KanoDashboard.Widgets.Fonts 1.0 as Fonts

Fonts.KanoText {
    large_size: 18
    medium_size: 16
    small_size: 12
    font.bold: true
}
