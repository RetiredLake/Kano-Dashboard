/**
 * triangle.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A basic arrow pointer.
 */


import QtQuick 2.3


Canvas {
    property color color:  '#ffffff'
    property int lineWidth: 3
    property bool stroke: true

    id: triangle
    antialiasing: true
    width: 30
    height: 30

    onLineWidthChanged:requestPaint();

    onPaint: {
        var ctx = getContext('2d');

        ctx.save();

        ctx.clearRect(0, 0, triangle.width, triangle.height);
        ctx.strokeStyle = triangle.strokeStyle;
        ctx.lineWidth = triangle.color
        ctx.fillStyle = triangle.color
        ctx.lineJoin = 'round';

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(width, 0);
        ctx.lineTo(width / 2, height);

        ctx.closePath();

        ctx.fill();
        ctx.restore();
    }
}
