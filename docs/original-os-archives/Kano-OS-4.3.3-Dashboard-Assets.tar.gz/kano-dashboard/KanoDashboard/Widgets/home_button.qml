/**
 * home_button.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Home icon
 */


import QtQuick 2.3
import KanoDashboard.Widgets.Templates 1.0 as Templates

Templates.FooterWidget {
    color: "#f67a3c"
    width: height
    title.image.source: 'home.png'
    title.image.anchors.centerIn: title
    title.image.anchors.margins: 10
    view: 'home'
}
