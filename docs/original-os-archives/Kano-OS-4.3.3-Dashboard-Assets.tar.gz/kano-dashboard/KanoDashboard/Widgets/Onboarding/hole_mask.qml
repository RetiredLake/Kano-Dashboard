/**
 * hole_mask.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A mask for isolating a widget. Is combined with an overlay to mask off the
 * widget.
 */


import QtQuick 2.3

Rectangle {
    property int hole_x
    property int hole_y
    property int hole_width
    property int hole_height
    property real hole_opacity: 0.5

    property var top_y: hole_y
    property var bottom_y: bottom_bar.y
    property var left_x: hole_x
    property var right_x: right_bar.x

    color: 'transparent'
    visible: false
    anchors.fill: parent

    Rectangle {
        id: left_bar
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        width: hole_x
        opacity: hole_opacity
    }
    Rectangle {
        id: top_bar
        anchors.top: parent.top
        height: hole_y
        x: hole_x
        width: hole_width
        opacity: hole_opacity
    }
    Rectangle {
        id: right_bar
        width: parent.width - (hole_x + hole_width)
        anchors.top: parent.top
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        opacity: hole_opacity
    }
    Rectangle {
        id: bottom_bar
        height: parent.height - (hole_y + hole_height)
        x: hole_x
        width: hole_width
        anchors.bottom: parent.bottom
        opacity: hole_opacity
    }
}
