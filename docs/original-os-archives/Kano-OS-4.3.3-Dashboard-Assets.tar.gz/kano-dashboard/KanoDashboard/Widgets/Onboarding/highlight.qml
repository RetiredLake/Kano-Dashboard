/**
 * highlight.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A component for highlighting a widget by combining an overlay with a mask
 * surrounding the widget. Also positions a pointer with instructions.
 */


import QtQuick 2.3
import QtQuick.Controls 1.4
import QtQuick.Controls.Styles 1.4
import QtGraphicalEffects 1.0

import KanoDashboard.Widgets.Onboarding 1.0 as Onboarding


Rectangle {
    property int border: 5
    property int highlight_x: 100
    property int highlight_y: 0
    property int highlight_width: width
    property int highlight_height: height
    property string highlight_description: ''
    property var highlight_widget
    property var click_widget: highlight_widget.highlight_click_widget || highlight_widget
    property var click_x: highlight_widget == click_widget ? 0 : click_widget.x
    property var click_y: highlight_widget == click_widget ? 0 : click_widget.y

    id: wrapper
    anchors.fill: parent
    color: 'transparent'

    states: [
        State {
            name: "shown"
            PropertyChanges {
                target: highlight_overlay
                visible: true
            }
            PropertyChanges {
                target: highlight_mouse
                enabled: true
                anchors.fill: wrapper
            }
        },
        State {
            name: "hidden"
            PropertyChanges {
                target: highlight_overlay
                visible: false
            }
            PropertyChanges {
                target: highlight_mouse
                enabled: false
                anchors.fill: wrapper
            }
        }
    ]
    state: 'shown'

    Rectangle {
        id: overlay
        anchors.fill: parent
        color: '#000000'
        visible: false
    }

    Onboarding.HoleMask {
        id: overlay_mask
        visible: false
        hole_x: highlight_x - wrapper.border
        hole_y: highlight_y - wrapper.border
        hole_width: highlight_width + 2 * wrapper.border
        hole_height: highlight_height + 2 * wrapper.border
    }

    OpacityMask {
        id: highlight_overlay
        anchors.fill: parent
        source: overlay
        maskSource: overlay_mask
        visible: false
    }

    Onboarding.Pointer {
        x: overlay_mask.left_x + click_x + click_widget.width
        y: overlay_mask.top_y + click_y
        height: click_widget.height
        text: highlight_description
    }

    MouseArea {
        id: highlight_mouse
        anchors.top: parent.top
        anchors.bottom: parent.top
        enabled: false
        propagateComposedEvents: true
        onClicked: {
            var x = mouse.x - highlight_x - click_x;
            var y = mouse.y - highlight_y - click_y;

            if (x < 0 || x > click_widget.width) {
                return true;
            }

            if (y < 0 || y > click_widget.height) {
                return true;
            }

            click_widget.area.clicked(mouse);
        }
    }
}
