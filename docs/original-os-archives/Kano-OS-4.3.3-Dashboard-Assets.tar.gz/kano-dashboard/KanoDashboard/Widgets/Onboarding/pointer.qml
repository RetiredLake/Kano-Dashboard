/**
 * pointer.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A tooltip arrow with description text.
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Onboarding 1.0 as Onboarding


Rectangle {
    id: wrapper
    property alias direction: wrapper.state
    property alias text: label.text
    color: 'transparent'
    anchors.margins: 0

    Onboarding.Triangle {
        id: triangle
        anchors.left: parent.left
        anchors.verticalCenter: parent.verticalCenter
        width: 30
        height: 30
    }

    Rectangle {
        property int margins: 10
        radius: 5
        anchors.verticalCenter: parent.verticalCenter
        anchors.left: triangle.right
        width: label.width
        height: label.height + 2 * margins
        Fonts.KanoText {
            id: label
            text: highlight_description
            color: '#ff6600'
            font.pixelSize: 20
            x: parent.margins
            y: parent.margins
        }
    }

    states: [
        State {
            name: 'left'
            PropertyChanges {
                target: label
                anchors.left: wrapper.left
            }
        },
        State {
            name: 'right'
            PropertyChanges {
                target: label
                anchors.right: wrapper.right
            }
        }
    ]
    state: 'left'
}
