/**
 * avatar.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget which draws the user's avatar with their progress to the next level
 * around it in a circular progress bar.
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Colours 1.0 as Colours


Templates.WidgetTemplate {
    color: "transparent"

    property var xp: kano_profile.calculate_xp()
    property var xp_to_next_level: kano_profile.get_xp_to_next_level()
    property var progress: kano_profile.get_progress_to_next_level()
    property var progress_angle: progress * 2 * Math.PI
    property int progress_bar_thickness: 8

    function refresh() {
        xp = kano_profile.calculate_xp();
        xp_to_next_level = kano_profile.get_xp_to_next_level();
        progress = kano_profile.get_progress_to_next_level();
        avatar.source = kano_profile.get_avatar_circ_image_path();
    }
    onUpdate: refresh()

    Canvas {
        id: canvas
        anchors.fill: parent

        onPaint: {
            var centerX = width / 2;
            var centerY = height / 2;
            var radius = Math.min(width, height) / 2;
            var lineWidth = 0;
            var offset = -Math.PI / 2;

            var ctx = canvas.getContext('2d')

            ctx.clearRect(0, 0, width, height);

            function drawArc(start, end, colour) {
                ctx.beginPath();
                ctx.moveTo(centerX, centerY);

                ctx.arc(centerX, centerY, radius, start + offset, end + offset, false);
                ctx.lineTo(centerX, centerY);

                ctx.fillStyle = colour;
                ctx.fill();

                ctx.lineWidth = lineWidth;
                ctx.strokeStyle = colour;
                ctx.stroke();
            }

            drawArc(0, 2 * Math.PI, Colours.Palette.button_color);
            drawArc(0, progress_angle, Colours.Palette.progress_color);
        }

        Image {
            id: avatar
            anchors.fill: parent
            anchors.margins: progress_bar_thickness
        }
    }
}
