/**
 * alert_card.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * An alert message in the form of a card
 */


import QtQuick 2.3
import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours

Item {
    signal button_clicked()

    property alias color: card.color
    property alias heading: text.text
    property alias image: image.source
    property alias button_text: btn.text
    property int margins: 10
    property bool loading: false
    property alias switch_mode: card.switch_mode
    property alias open_view: card.open_view
    property alias guide_height: item.height

    id: item
    height: 125
    anchors.left: parent.left
    anchors.right: parent.right

    Templates.WidgetTemplate {
        id: card
        anchors.fill: parent
        loading: parent.loading
        area.z: 100
        scale: area.containsMouse ? 1.02 : 1.0
        area.onEntered: app_state.play_hover_sound()
        anchors.margins: 0

        activatable: true
        clip: true

        Templates.ImageWidget {
            id: image
            anchors.left: parent.left
            anchors.right: contents.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom

            anchors.rightMargin: -10
            anchors.topMargin: parent.height * 0.1
            anchors.bottomMargin: anchors.topMargin
            img.horizontalAlignment: Image.AlignRight
            clip: true
        }

        Item {
            id: contents
            height: text.height + btn.height + 10
            width: parent.width * 0.75
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter

            Fonts.H3 {
                id: text
                text: heading
                color: '#ffffff'

                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.leftMargin: 2 * margins
            }

            Templates.ButtonWidget {
                id: btn
                anchors.top: text.bottom
                anchors.left: text.left
                anchors.leftMargin: 0
                color: Qt.darker(card.color, 1.1)
                text_color: Colours.Palette.button_text_color

                area.propagateComposedEvents: true
                onClicked: mouse.accepted = false
                activatable: true
                area.hoverEnabled: false
            }
        }


        onClicked: button_clicked()
    }
}
