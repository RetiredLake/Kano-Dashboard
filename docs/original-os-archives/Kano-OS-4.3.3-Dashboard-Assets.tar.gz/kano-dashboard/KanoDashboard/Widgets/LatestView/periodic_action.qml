/**
 * periodic_action.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget which allows a process to be run at a set interval, offset by a chosen
 * time.
 */


import QtQuick 2.3

import Kano.Process 1.0

Rectangle {
    property string cmd: ''
    property int second: 1000
    property int minute: 60 * second
    property int hour: 60 * minute
    property int day: 60 * hour
    property int week: 7 * day
    property int interval: day
    property int offset: 10 * minute * Math.random()

    id: periodic_timer

    Process {
        id: proc
        onFinished: timer.start()
    }

    Timer {
        id: offset_timer
        running: true
        repeat: false
        interval: periodic_timer.offset
        onTriggered: proc.start(cmd)
    }

    Timer {
        id: timer
        running: false
        repeat: false
        interval: periodic_timer.interval
        onTriggered: proc.start(cmd)
    }
}
