import QtQuick 2.3
import QtGraphicalEffects 1.0
import QtQml 2.2
import Updates 1.0

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts

Rectangle {
    id: card

    property alias text: card_txt.text
    property alias button_text: card_btn.text
    property alias button_action: card_btn.open_view
    property alias button_colour: card_btn.color

    property int available_margin: (width - card_btn.text_width) / 2
    property int min_padding: 20
    property int max_margin: Math.min(30, available_margin - min_padding)
    property int button_margin: Math.min(
        available_margin, max_margin
    )

    height: Math.max(data.height * 1.5, width * 0.5)

    anchors.left: parent.left
    anchors.right: parent.right

    Item {
        id: data
        height: card_txt.height + card_btn.height + spacing
        width: parent.width
        anchors.centerIn: parent

        Fonts.H3 {
            id: card_txt
            color: '#ffffff'
            lineHeight: 1.3

            horizontalAlignment: Text.AlignHCenter
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
        }

        Templates.SquareButton {
            id: card_btn
            hover_colour: Qt.lighter(color, 1.1)

            anchors.left: parent.left
            anchors.right: parent.right
            anchors.leftMargin: card.button_margin
            anchors.rightMargin: card.button_margin

            anchors.bottom: parent.bottom
            anchors.bottomMargin: 0
        }
    }
}
