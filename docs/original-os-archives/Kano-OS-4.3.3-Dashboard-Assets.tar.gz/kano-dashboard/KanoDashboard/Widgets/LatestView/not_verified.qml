/**
 * not_verified.qml
 *
 * Copyright (C) 2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Notifies that the user's account isn't verified
 */


import QtQuick 2.3
import QtGraphicalEffects 1.0
import QtQml 2.2
import Updates 1.0

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.LatestView 1.0 as LatestView


LatestView.AlertView {
    id: no_profile
    title.text: qsTr('Verify account')

    Templates.WidgetTemplate {
        id: card
        anchors.top: parent.title.bottom
        property alias guide_height: card.height
        height: 125
        anchors.left: parent.left
        anchors.right: parent.right
        color: '#38495c'
        property int margins: 10
        loading: false
        area.z: 100
        anchors.margins: 0

        activatable: true
        clip: true

        Templates.ImageWidget {
            id: image
            source: 'verify_account.png'
            anchors.left: parent.left
            anchors.right: contents.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom

            anchors.rightMargin: -10
            anchors.topMargin: parent.height * 0.1
            anchors.bottomMargin: anchors.topMargin
            img.horizontalAlignment: Image.AlignRight
            clip: true
        }

        Item {
            id: contents
            height: text.height + subtitle.height + card.margins
            width: parent.width * 0.75
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter

            Fonts.H3 {
                id: text
                text: qsTr('Verify your account')
                color: '#ffffff'

                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.leftMargin: 2 * card.margins
            }

            Fonts.H5 {
                id: subtitle
                text: qsTr("Your account hasn't been given consent. Activate to unlock more")
                color: '#ffffff'

                anchors.bottom: parent.bottom
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.leftMargin: 2 * card.margins
                anchors.rightMargin: 2 * card.margins
            }
        }
    }
}
