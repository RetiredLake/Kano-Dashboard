/**
 * live_tiles.qml
 *
 * Copyright (C) 2016-2019 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget to show a live feed of tiles as provided by KESDLT
 */


import QtQuick 2.3
import QtQuick.Controls 1.4

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.LatestView 1.0 as LatestView
import KanoDashboard.Widgets.LiveTile 1.0 as LiveTile
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Colours 1.0 as Colours


Templates.WidgetTemplate {
    id: live_tiles
    property int margins: 5
    x: margins / 2

    Component.onCompleted: {
        app_state.refresh.connect(tileGrid.tileList.refresh);
        tileGrid.tileList.refresh();
    }

    title.text: qsTr("Staff Picks")
    activatable: false

    BusyIndicator {
        anchors.centerIn: parent
        visible: tileGrid.tileList.length == 0
        running: visible
    }

    LiveTile.TileGrid {
        id: tileGrid
        rows: 2
        columns: 2
        model: layout.tile
        anchors.top: parent.title.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        height: width

        onTileClicked: {
            live_tiles.open_view = 'chromium-browser --start-maximized --force-device-scale-factor=1.2 ' + tile.openUrl;
            live_tiles.area.activate();
        }
    }

    Templates.WidgetTemplate {
        id: more_creations

        property color overlay_color: Colours.Palette.dark_color
        property int padding: 15
        property int elements_spacing: 8

        open_view: 'kano-world-launcher'

        color: area.containsMouse ?
            Colours.Palette.dark_color : Colours.Palette.button_color

        width: (text.width + elements_spacing + right_arrow_image.width) + (2 * radius)
        height: Math.max(text.height, right_arrow_image.height) + 2 * padding
        radius: height / 2
        activatable: true
        hover_sound_enabled: true
        area.z: 100

        anchors.top: tileGrid.bottom
        anchors.horizontalCenter: parent.horizontalCenter

        Fonts.H3 {
            id: text
            text: qsTr('More Creations')

            color: parent.area.containsMouse ?
                Colours.Palette.button_text_color : parent.overlay_color

            anchors.left: parent.left
            anchors.leftMargin: parent.radius
            anchors.verticalCenter: parent.verticalCenter
        }

        Templates.ImageWidget {
            id: right_arrow_image
            source: 'right_arrow.png'
            height: img.sourceSize.height
            width: img.sourceSize.width

            overlay.color: parent.area.containsMouse ? 'white' : parent.overlay_color

            anchors.left: text.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.leftMargin: parent.elements_spacing
        }
    }
}
