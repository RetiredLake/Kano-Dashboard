/**
 * update_notification.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Widget to initiate the install of a single individual package update
 */


import QtQuick 2.3

import Kano.Process 1.0

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.LatestView 1.0 as LatestView

LatestView.AlertCard {
    signal update_finished()
    property string pkg: ''

    function get_pkg_label(pkg_str) {
        switch (pkg_str) {
        case 'kano-overworld':
            return qsTr('Story Mode Update');
        default:
            return pkg_str + qsTr(' Update');
        }
    }

    color: '#5f8586'
    heading: get_pkg_label(pkg)
    image: 'story_update.png'
    button_text: qsTr('Install')


    Process {
        id: install_process
        onFinished: {
            loading = false;
            update_finished();
        }
    }

    onButton_clicked: {
        loading = true;
        install_process.start(
            'sudo kano-updater update-ind-pkg ' + pkg
        );
    }
}
