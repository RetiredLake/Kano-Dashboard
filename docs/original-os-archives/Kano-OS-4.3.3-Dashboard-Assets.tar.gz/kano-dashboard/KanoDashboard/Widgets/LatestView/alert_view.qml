/**
 * alert_view.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 *
 */


import KanoDashboard.Widgets.Templates 1.0 as Templates


Templates.WidgetTemplate {
    property int guide_height: height
}
