/*
 * popup_template.qml
 *
 * Copyright (C) 2017 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Template for all popups
 *
 * Customise with something like:
 *
 *     PopupTemplate {
 *         signal event()
 *
 *         Text {
 *             anchors.centreIn: parent
 *             text: qsTr('Some message')
 *         }
 *     }
 *
 * Include in the main window through a Component and Loader:
 *
 *     Component {
 *         id: popup_component
 *         PopupWidget {
 *             onEvent: handle_event()
 *         }
 *     }
 *
 *     Loader {
 *         sourceComponent: condition ? popup_component : null
 *     }
 *
 */


import QtQuick 2.3

Item {
    default property alias _contentChildren: popup_contents.data
    property alias popup_width: popup_dialog.width
    property alias popup_height: popup_dialog.height
    property alias color: popup_dialog.color

    Rectangle {
        id: bg_blur
        color: "black"
        anchors.fill: parent
        opacity: 0.5
        z: -5

        // Capture and discard mouse events to prevent propagation
        MouseArea {
            anchors.fill: parent
            enabled: true
            hoverEnabled: true
        }
    }

    Rectangle {
        id: popup_dialog
        z: 10
        radius: 10
        width: popup_contents.childrenRect.width + 2 * popup_contents.anchors.margins
        height: popup_contents.childrenRect.height + 2 * popup_contents.anchors.margins
        anchors.centerIn: parent

        Item {
            id: popup_contents
            anchors.fill: parent
            anchors.margins: 50
        }
    }
}
