/*
 * boot_warning.qml
 *
 * Copyright (C) 2017 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * For CKCv1 customers, show information about how to get a free upgrade to
 * their speaker
 *
 * TODO: This can be removed as soon as we are confident that all affected
 *       customers have redeemed this offer
 *
 */

import QtQuick 2.3

import KanoDashboard.Popups 1.0 as Popups
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Templates 1.0 as Templates


Popups.PopupTemplate {
    signal claim()
    signal dismiss()

    property QtObject palette: Item {
        property color bg_colour: '#ffffff'
        property color text_colour: '#394148'
        property color action_bg_colour: '#f0722e'
        property color action_fg_colour: '#ffffff'
    }

    id: popup

    color: palette.bg_colour
    popup_width: 600

    Image {
        id: img
        fillMode: Image.PreserveAspectFit
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.leftMargin: 30
        anchors.rightMargin: 30
        source: 'speaker.png'
    }

    Fonts.H1 {
        id: title
        horizontalAlignment: Text.AlignHCenter
        anchors.top: img.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.topMargin: 30
        color: palette.text_colour
        font.capitalization: Font.Capitalize
        text: qsTr('Free speaker upgrade')
    }

    Fonts.H2 {
        id: description
        horizontalAlignment: Text.AlignHCenter
        anchors.topMargin: 15
        anchors.top: title.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        color: palette.text_colour
        font.bold: false
        text: qsTr('To claim your free speaker, click the button below')
    }

    Templates.ButtonWidget {
        id: claim_btn
        text: qsTr('Get speaker')
        text_capitalization: Font.AllUppercase
        text_color: palette.action_fg_colour

        color: area.containsMouse ?
            Qt.darker(palette.action_bg_colour, 1.1) :
            palette.action_bg_colour

        radius: height / 2
        width: text_width + height
        anchors.top: description.bottom
        anchors.topMargin: 30
        anchors.horizontalCenter: parent.horizontalCenter

        onClicked: popup.claim()
    }

    Templates.ButtonWidget {
        text: qsTr('Close')
        text_capitalization: Font.AllUppercase
        text_color: palette.action_bg_colour

        color: area.containsMouse ?
            Qt.darker(palette.action_fg_colour, 1.1) :
            palette.action_fg_colour

        radius: height / 2
        width: text_width + height
        anchors.top: description.bottom
        anchors.right: parent.right
        anchors.topMargin: 30

        onClicked: popup.dismiss()
    }

}
