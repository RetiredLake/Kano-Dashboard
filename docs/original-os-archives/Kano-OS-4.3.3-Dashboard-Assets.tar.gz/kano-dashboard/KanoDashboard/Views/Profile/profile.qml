/**
 * profile.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * The profile view
 */


import QtQuick 2.3

import KanoDashboard.Views.Profile 1.0 as Profile
import KanoDashboard.Views.Common 1.0 as CommonView

CommonView.View {
    name: qsTr("Profile")

    Profile.Content {
        id: content
        color: "transparent"

        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: contentFooter.top
    }
}
