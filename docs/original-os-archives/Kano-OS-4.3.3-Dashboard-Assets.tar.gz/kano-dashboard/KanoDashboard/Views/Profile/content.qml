/**
 * content.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Houses the main content of the profile
 */


import QtQuick 2.3

import KanoDashboard.Widgets 1.0 as Widgets
import KanoDashboard.Widgets.StoryMode 1.0 as StoryMode

Rectangle {
    Widgets.HomeButton {
    }
}
