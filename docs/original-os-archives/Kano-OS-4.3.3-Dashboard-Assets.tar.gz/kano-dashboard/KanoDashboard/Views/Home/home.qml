/**
 * home.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * The home view
 */


import QtQuick 2.3

import KanoDashboard.Views.Home 1.0 as Home
import KanoDashboard.Views.Common 1.0 as CommonView

CommonView.View {
    icon: 'home.png'
    property alias content: content
    onUpdate: content.update()

    Home.Content {
        id: content
        color: "transparent"
        z: -1

        anchors.fill: parent
    }
}
