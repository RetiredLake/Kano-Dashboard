/**
 * content.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Contains the main body of the home screen
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Apps 1.0 as Apps
import KanoDashboard.Widgets.StoryMode 1.0 as StoryMode
import KanoDashboard.Widgets.LatestView 1.0 as LatestView
import KanoDashboard.Views.Common 1.0 as CommonView

CommonView.WidgetGroup {
    property alias story_mode: story_mode
    property alias apps: apps
    property alias shares: shares
    onUpdate: shares.update()

    property int max_side_width: (width - (apps.width + 2 * apps.side_margins)) / 2

    StoryMode.StoryMode {
        id: story_mode
        anchors.top: parent.top
        anchors.right: apps.left

        max_width: max_side_width
        guide_height: 2 * apps.guide_height

        anchors.rightMargin: apps.side_margins
    }

    Apps.CreativeMode {
        id: apps
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    LatestView.Notifications {
        id: shares
        anchors.top: parent.top
        anchors.left: apps.right

        width: story_mode.width
        guide_height: apps.guide_height - apps.cell_margin

        anchors.leftMargin: apps.side_margins
    }
}
