/**
 * footer.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Houses the bottom row of home screen widgets
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Apps 1.0 as Apps
import KanoDashboard.Widgets.PowerMenu 1.0 as PowerMenu
import KanoDashboard.Views.Common 1.0 as CommonView

CommonView.WidgetGroup {
    height: power_button.height
    property alias profile: profile

    Apps.Profile {
        id: profile
        anchors.top: parent.top
        anchors.right: internet.left
    }
}
