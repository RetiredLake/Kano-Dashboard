/**
 * header.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Houses the top row's title and user progress
 */


import QtQuick 2.3

import KanoDashboard.Views.Common 1.0 as CommonView
import KanoDashboard.Widgets.UserProgress 1.0 as UserProgress
import KanoDashboard.Widgets.Fonts 1.0 as Fonts
import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Notifications 1.0 as Notifications

CommonView.WidgetGroup {
    onUpdate: progress.update()

    height: 70 + spacing
    property string title: ''
    property string icon
    anchors.margins: spacing

    UserProgress.UserProgress {
        id: progress
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.margins: 0
    }

    Component {
        id: screen_name
        Fonts.H1 {
            text: title
        }
    }

    Loader {
        sourceComponent: title ? screen_name : undefined
        anchors.bottom: icon.bottom
        anchors.left: icon.right
        anchors.centerIn: parent
    }

    Notifications.NotificationBadge {
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.topMargin: progress.progress_bar_thickness
        anchors.bottomMargin: anchors.topMargin
        anchors.rightMargin: 0
    }

}
