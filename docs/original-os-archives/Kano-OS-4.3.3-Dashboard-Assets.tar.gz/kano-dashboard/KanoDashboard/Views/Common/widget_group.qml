/**
 * widget_group.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A collection of widgets which adds the standard widget signals
 */


import QtQuick 2.3

Rectangle {
    id: wrapper
    signal fade_in()
    signal fade_out()
    signal change_view(string view)
    signal highlight(int x, int y, variant widget)
    signal update()

    property int spacing: 15

    onFade_in: {
        if (parent.fade_in !== undefined) {
            parent.fade_in()
        }
    }
    onFade_out: {
        if (parent.fade_out !== undefined) {
            parent.fade_out()
        }
    }
    onChange_view: {
        if (parent.change_view !== undefined) {
            parent.change_view(view)
        }
    }
    onHighlight: {
        if (parent.highlight !== undefined) {
            parent.highlight(
                (wrapper.x + x),
                (wrapper.y + y),
                widget
            );
        }
    }
}
