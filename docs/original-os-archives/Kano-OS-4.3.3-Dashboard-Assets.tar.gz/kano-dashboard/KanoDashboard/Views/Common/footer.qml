/**
 * footer.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Houses the bottom row status icons
 */


import QtQuick 2.3

import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Status 1.0 as Status
import KanoDashboard.Widgets.Apps 1.0 as Apps
import KanoDashboard.Widgets.PowerMenu 1.0 as PowerMenu
import KanoDashboard.Widgets.Colours 1.0 as Colours

import Kano.Apps 1.0 as KanoApps


Templates.WidgetTemplate {
    height: 70
    spacing: 15
    anchors.margins: spacing
    property int padding: spacing / 2
    onUpdate: wifi.update()

    PowerMenu.PowerButton {
        id: power_button
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.topMargin: 0
        anchors.bottomMargin: 0
    }

    Apps.ComputerMode {
        id: computer_mode
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.left: power_button.right
        anchors.topMargin: 0
        anchors.bottomMargin: 0
    }

    KanoApps.AppGridControl {
        id: app_grid_control
        anchors.verticalCenter: parent.verticalCenter
        anchors.horizontalCenter: parent.horizontalCenter
        indicator_color: Colours.Palette.dark_color

        Binding {
            target: app_state
            property: 'app_grid_control'
            value: app_grid_control
        }
    }

    Apps.Settings {
        id: settings
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.right: audio.left
        anchors.topMargin: 0
        anchors.bottomMargin: 0
    }

    Status.AudioStatus {
        id: audio
        z: 1

        anchors.right: wifi.left
        anchors.bottom: parent.bottom
        anchors.top: parent.top
        anchors.topMargin: 0
        anchors.bottomMargin: 0
    }

    Status.WiFiStatus {
        id: wifi
        z: 1

        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.top: parent.top
        anchors.topMargin: 0
        anchors.bottomMargin: 0
    }
}
