/**
 * view.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Base class for views
 */


import QtQuick 2.3
import KanoDashboard.Views.Common 1.0 as CommonView

CommonView.WidgetGroup {
    id: view

    default property alias _contentChildren: content.data
    property alias name: header.title
    property alias icon: header.icon
    property alias header: header
    property alias footer: footer
    property int spacing: 0

    onUpdate: {
        header.update();
        footer.update();
    }

    color: "transparent"

    Header {
        id: header
        color: "transparent"

        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
    }

    Item {
        id: content

        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: footer.top

        anchors.topMargin: view.spacing
        anchors.bottomMargin: view.spacing
    }

    Footer {
        id: footer
        color: "transparent"

        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
    }
}
