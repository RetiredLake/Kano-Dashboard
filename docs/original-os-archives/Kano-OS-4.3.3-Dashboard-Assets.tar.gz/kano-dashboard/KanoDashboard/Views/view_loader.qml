/**
 * view_loader.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * A component to load the different screens (Home/Profile/...)
 */


import QtQuick 2.3
import KanoDashboard.Views.Home 1.0 as Home
import KanoDashboard.Views.Profile 1.0 as Profile

import KanoDashboard.Views.Common 1.0 as CommonView
import KanoDashboard.Widgets.Styles 1.0 as Styles

CommonView.WidgetGroup {
    property var overscan: {
        'top': 50,
        'bottom': 50,
        'left': Styles.Resolution.resolution == Styles.Resolution.low ?
            50 :
            100,
        'right': Styles.Resolution.resolution == Styles.Resolution.low ?
            50 :
            100,
    }

    id: view_loader
    anchors.fill: parent
    color: 'transparent'
    onUpdate: {
        viewLoader.item.update()
    }

    Component {
        id: home
        Home.Home {
        }
    }

    Component {
        id: profile
        Profile.Profile {
        }
    }

    Loader {
        id: viewLoader
        anchors.fill: parent
        anchors.topMargin: overscan.top
        anchors.bottomMargin: overscan.bottom
        anchors.leftMargin: overscan.left
        anchors.rightMargin: overscan.right
        sourceComponent: home
    }
}
