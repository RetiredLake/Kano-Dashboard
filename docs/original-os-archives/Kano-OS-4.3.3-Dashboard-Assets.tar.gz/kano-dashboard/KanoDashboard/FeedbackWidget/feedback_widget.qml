/*
 *  feedback_widget.qml
 *
 *  Copyright (C) 2016 Kano Computing Ltd.
 *  License: http://www.gnu.org/licenses/gpl-2.0.txt GNU General Public License v2
 *
 *  Feedback Widget embedded in the Dashboard.
 *
 *  The dialog pops up centered on the screen, blurring the background desktop.
 *  Clicking outside the dialog will dismiss it.
 *
 */

import QtQuick 2.3
import QtQuick.Controls 1.4
import QtQuick.Layouts 1.2
import QtQuick.Controls.Styles 1.4

import Kano.Process 1.0

import KanoDashboard.Widgets.Fonts 1.0 as Fonts


Item {
    property QtObject palette: Item {
        property color background_colour: '#67a1de'
        property color input_colour: '#5d91c7'
        property color input_selected_colour: '#3d61ac'
        property color instructions_colour: input_colour
        property color dark_text_color: '#4f7aa6'
        property color submit_colour: '#78c573'
        property color skip_colour: '#4f7aa6'
    }

    Rectangle {
        id: blur_desktop
        color: "black"
        anchors.fill: parent
        opacity: 0.5
        z: -5

        MouseArea {
            anchors.fill: parent

            // both enablements below effectively prevent Dashboard icons responsiveness
            enabled: true
            hoverEnabled: true

            onClicked: {
                // allow to close by clicking outside the dialog,
                // only on the first screen. Mark it as skipped
                if (second_screen.visible==false) {
                   console.log ("Clicked outside dialog, dismissing feedback widget");
                   app_state.set_feedback_control_file("skipped");
                   loader_feedback_widget.source="";
                }
            }
        }
    }

    Process {
       id: proc_send_feedback

       onReadyRead: {
          var response="" + readAll();
          console.log("Feedback CLI response: " + response);

          if (response == "OK\n") {
             console.log("Feedback has been correctly sent");

             // Put mark in the control file
             app_state.set_feedback_control_file("sent");
          }
          else {
             console.log("Error sending Feedback");
          }

          // close the widget, return to Dashboard
          loader_feedback_widget.source="";
       }
    }

    Rectangle {
        // this rectangle covers the complete dialog,
        // is used to later determine position and boundaries
        id: popup_dialog
        z: 10
        color: "transparent"
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width / 1.5
        height: parent.height / 2.0

        MouseArea {
            anchors.fill: parent
            onClicked: {
                console.log ("clicked on dialog, disregard");
            }
        }

        Row {
            // the row embraces both the left and right panels.

            // Negative spacing is used here so that the round corners
            // apply only to left and right sides of the dialog
            spacing: -20

            // this is the left side panel in the dialog
            Rectangle {
                id: left_panel
                radius: 10
                width: popup_dialog.width / 3
                height: popup_dialog.height
                color: palette.instructions_colour

                ColumnLayout {
                    id: left_pane_col
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.margins: 25
                    spacing: 50

                    Fonts.H1 {
                        color: palette.dark_text_color
                        text: qsTr("Feedback")
                    }

                    Fonts.H1 {
                        id: question_left
                        Layout.maximumWidth: left_pane_col.width
                        color: "white"
                        lineHeight: 1.1
                        font.bold: false
                        // textFormat: Text.StyledText
                        text: qsTr(
                            "Hey <b>%1</b>,<br>how would you rate your " +
                            "experience with kano so far?"
                        ).arg(q_kano_world.get_username())
                    }
                }

                // Button: SKIP_THIS
                Rectangle {
                    id: skip_button
                    anchors.bottom: parent.bottom
                    anchors.left: parent.left
                    anchors.margins: 25
                    radius: 6
                    width: 150
                    height: 60
                    color: skip_area.containsMouse ?
                        Qt.darker(palette.skip_colour, 1.1) :
                        palette.skip_colour
                    MouseArea {
                        id: skip_area
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        hoverEnabled: true
                        onClicked: {
                            // remember we skipped, unload widget, return to Dashboard.
                            console.log("clicked SKIP THIS");
                            app_state.set_feedback_control_file("skipped");
                            loader_feedback_widget.source=""
                        }
                    }
                    Fonts.H2 {
                        anchors.centerIn: parent
                        color: "white"
                        text: qsTr("SKIP THIS")
                    }
                }
            }

            // this is the right side panel in the dialog
            Rectangle {
                id: right_panel
                radius: 6
                width: popup_dialog.width / 1.3
                height: popup_dialog.height
                color: palette.background_colour

                Rectangle {
                    // Hide the left-hand corner radius
                    anchors.left: parent.left
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    color: parent.color
                    width: parent.radius
                }

                Flow {
                    id: numbers
                    spacing: width * 0.03
                    flow: Flow.LeftToRight
                    property int rate_number: -1

                    anchors {
                        fill: parent
                        topMargin: 150
                        leftMargin: 50
                        rightMargin: 50
                    }

                    Repeater {
                        id: number_repeater
                        property int cell_width: (numbers.width / 6) - numbers.spacing
                        model: 11

                        // Button: These are the numbered boxes to click
                        Rectangle {
                            width: number_repeater.cell_width
                            height: width
                            radius: 6
                            border.color: 'white'
                            border.width: mouse_on_number.containsMouse ? 5 : 0
                            color: mouse_on_number.containsMouse ?
                                palette.input_selected_colour :
                                palette.input_colour
                            MouseArea {
                                id: mouse_on_number
                                cursorShape: Qt.PointingHandCursor
                                anchors.fill: parent
                                hoverEnabled: true
                                onClicked: {
                                    // Unfold the second screen
                                    // save rate number to submit to kano
                                    numbers.rate_number = index;
                                    console.log ("clicked on rate: " + numbers.rate_number);

                                    numbers.visible = false;
                                    x_button.visible = false;
                                    second_screen.visible = true;

                                    // Prepare the text area to quickly type in
                                    if (!q_kano_world.is_registered() || !q_kano_world.is_account_verified()) {
                                        user_feedback.text = qsTr("Want to send us more information? Ask your parent to check their email.");
                                    } else {
                                        user_feedback.text = qsTr("Type your answer here");
                                    }
                                    user_feedback.selectAll();

                                    // Set the question based on user rating
                                    if (numbers.rate_number <= 4) {
                                        question_left.text = qsTr("Oh no,<br>what did we do wrong?");
                                    }
                                    else if (numbers.rate_number >= 5 && numbers.rate_number <= 7) {
                                        question_left.text = qsTr("Thank you!<br>How can we improve?");
                                    }
                                    else {
                                        // from 8 to 10
                                        question_left.text = qsTr("Thanks! Can you tell us<br>" +
                                            "what you liked so much?");
                                    }
                                }
                            }

                            // This is the number rendered in the box
                            Fonts.H1 {
                                color: "white"
                                anchors.centerIn: parent
                                font.pixelSize: parent.height / 2

                                // Info on why we localize the number:
                                // http://doc.qt.io/qt-5/qml-qtqml-number.html
                                text: Number(index).toLocaleString(Qt.locale(), "f", 0)
                            }
                        }
                    }
                }

                // Button: X (close)
                Rectangle {
                    id: x_button
                    x: parent.width - 100
                    y: 30
                    radius: 10
                    width: 50
                    height: 50
                    color: "transparent"
                    MouseArea {
                        id: close_area
                        hoverEnabled: true
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            // unload the feedback widget, return to Dashboard
                            // mark widget as skipped
                            console.log("clicked X");
                            app_state.set_feedback_control_file("skipped");
                            loader_feedback_widget.source=""
                        }
                    }
                    Fonts.H1 {
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.verticalCenter: parent.verticalCenter
                        color: close_area.containsMouse ?
                            Qt.darker(palette.input_colour, 1.1) :
                            palette.input_colour
                        text: '\xD7'
                        font.pixelSize: parent.height
                    }
                }

                Item {
                    id: second_screen
                    visible: false
                    anchors.fill: parent
                    property var editor_side_margins: 150
                    property var editor_top_margin: 100

                    // Edit area where the user types
                    TextArea {
                        id: user_feedback
                        visible: true
                        y: parent.editor_top_margin
                        x: parent.editor_side_margins
                        width: second_screen.width - parent.editor_side_margins * 2
                        height: second_screen.height / 2
                        wrapMode: TextEdit.WordWrap
                        focus: true
                        font.pointSize: 18
                        textMargin: 25
                        readOnly: !q_kano_world.is_registered() || !q_kano_world.is_account_verified()

                        style: TextAreaStyle {
                            textColor: "white"
                            selectionColor: "steelblue"
                            selectedTextColor: "#eee"
                            backgroundColor: palette.input_colour

                            // FIXME: Cannot set round corners
                            Rectangle {
                                anchors.fill: parent
                                radius: 10
                                color: "#457fb1"
                                border.color: "#447eb0"
                                border.width: 3
                            }
                        }
                    }

                    // Button: Submit
                    Rectangle {
                        id: submit_button
                        property string cmdline: ''
                        y: second_screen.height - height - 25
                        anchors.horizontalCenter: second_screen.horizontalCenter
                        visible: true
                        radius: 10
                        width: 200
                        height: 60
                        color: submit_mouse_area.containsMouse ?
                            Qt.darker(palette.submit_colour, 1.1) :
                            palette.submit_colour

                        BusyIndicator {
                           id: network_busy
                           running: false
                           anchors.centerIn: parent
                           visible: false
                           z: 100
                        }

                        MouseArea {
                            id: submit_mouse_area
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            hoverEnabled: true
                            onClicked: {
                                // Start the program to send feedback to us
                                console.log("Feedback is being submitted...");

                                // Show progress circle, disable interactive elements
                                network_busy.running=true;
                                network_busy.visible=true;
                                skip_button.enabled=false;
                                user_feedback.enabled=false;

                                // Send question ID, rate number, and user comments to Kano
                                // We send the answer in two questions: rate number and explanation text.

                                // Replace double quotation marks to single ones
                                user_feedback.text=user_feedback.text.replace(new RegExp('"', 'g'), "'");

                                submit_button.cmdline='kano-feedback-widget-cli --print-success ' +
                                '"5787ac06e98ae8816fb86b15" "' + numbers.rate_number + '" ' +
                                '"578cbf79b1eafe4c58c76932" "' + user_feedback.text + '"';

                                console.log("cmdline: " + submit_button.cmdline);
                                proc_send_feedback.start(submit_button.cmdline)
                            }
                        }
                        Fonts.H2 {
                            anchors.centerIn: parent
                            color: "white"
                            text: qsTr("SUBMIT")
                        }
                    }
                }
            }
        }
    }
}
