/*
 * wallpaper.qml
 *
 * Copyright (C) 2017 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Functions to get the system wallpaper
 *
 * TODO: Compeletely factor this out to allow addition in the SDK. Right now
 *       it is very similar to that used in Overture.
 *
 */


pragma Singleton
import QtQuick 2.0


QtObject {
    readonly property url system_wallpaper_path:
        Qt.platform.os == 'linux' ?
            '/usr/share/kano-desktop/wallpapers/' :
            // Try location of likely kano-desktop repo checkout
            '../../../../../kano-desktop/wallpapers/'

    function get_wallpaper_aspect_ratio(width, height) {
        var ratio;

        if (width <= 1024) {
            return '1024';
        }

        ratio = width / height;

        switch (ratio) {
        case 4 / 3:
            return '4-3';
        case 16 / 9:
        case 16 / 10:
        default:
            return '16-9';
        }
    }

    function get_system_wallpaper(wallpaper, width, height) {
        return system_wallpaper_path + wallpaper + '-' + get_wallpaper_aspect_ratio(width, height) + '.png';
    }
}
