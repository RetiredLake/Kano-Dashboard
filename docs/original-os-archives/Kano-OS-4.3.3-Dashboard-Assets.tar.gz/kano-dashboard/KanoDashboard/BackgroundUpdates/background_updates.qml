/*
 *  background_updates.qml
 *
 *  Copyright (C) 2016 Kano Computing Ltd.
 *  License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 *  Screen to be displayed at Dashboard load time, when the background updates
 *  have been downloaded and are ready to be installed.
 *
 *  This screen will simply ask for confirmation to install the updates and reboot.
 *
 */

import QtQuick 2.3
import QtQuick.Controls 1.4
import QtQuick.Layouts 1.2
import QtQuick.Controls.Styles 1.4

import Kano.Process 1.0

import KanoDashboard.Widgets.Fonts 1.0 as Fonts

Item {

    // TODO: Encapsulate into a reusable component (see QML object FeedbackWidget)
    property QtObject palette: Item {
        property color instructions_colour: '#5d91c7'
        property color dark_text_color: '#4f7aa6'
        property color update_colour: '#4f7aa6'
    }

    Rectangle {
        id: blur_desktop
        color: "black"
        anchors.fill: parent
        opacity: 0.5
        z: -5

        MouseArea {
            // effectively captures and discards mouse events
            // trespassing down to the Dashboard.
            anchors.fill: parent
            enabled: true
            hoverEnabled: true
        }
    }

    Process {
        id: proc_update_kit
        onFinished: {
            // Close the popup and return to the Dashboard
            loader_background_updates.source="";
            app_state.fade_in();
        }
    }

    Rectangle {
        // this rectangle covers the complete popup dialog.
        id: popup_dialog
        z: 10
        color: "transparent"
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width / 1.5
        height: parent.height / 2.0

        MouseArea {
            // capture and discard mouse events on the popup
            anchors.fill: parent
        }

        // this is the actual popup content
        Rectangle {
            id: content_panel
            radius: 10
            width: popup_dialog.width
            height: popup_dialog.height
            color: palette.instructions_colour

            ColumnLayout {
                id: panel_column
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.margins: 25
                spacing: 50

                Fonts.H1 {
                    color: palette.dark_text_color
                    text: qsTr("Updates Ready!")
                }

                Fonts.H1 {
                    Layout.maximumWidth: panel_column.width
                    color: "white"
                    lineHeight: 1.1
                    font.bold: false
                    text: qsTr(
                    "Hey <b>%1</b>,<br><br>" +
                    "We've got new apps, games, and challenges for you. Want them?<br>"
                    ).arg(q_kano_world.get_username())
                }
            }

            // TODO: Encapsulate to use Button templates (see QML object FeedbackWidget)
            // Button: INSTALL NOW
            Rectangle {
                id: update_button
                anchors.bottom: parent.bottom
                anchors.left: parent.left
                anchors.margins: 25
                radius: 6
                width: 250
                height: 60
                color: update_button_area.containsMouse ?
                Qt.darker(palette.update_colour, 1.1) :
                palette.update_colour

                MouseArea {
                    id: update_button_area
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true
                    onClicked: {
                        // Hide the Dashboard and the updates Dialog.
                        // Launch the Gtk interactive update, it should reboot and not return
                        blur_desktop.visible=false;
                        popup_dialog.visible=false;
                        app_state.fade_out();

                        // Remove the postpone updates mark file, and launch the update
                        app_state.updates_set_completed();
                        proc_update_kit.start(app_state.upgradeCommand)
                    }
                }

                Fonts.H2 {
                    anchors.centerIn: parent
                    color: "white"
                    text: qsTr("Update Now")
                }
            }

            // TODO: Encapsulate to use Button templates (see QML object FeedbackWidget)
            // Button: LATER
            Rectangle {
                id: later_button
                visible: true
                anchors.bottom: parent.bottom
                anchors.left: update_button.right
                anchors.margins: 25
                radius: 6
                width: 150
                height: 60
                color: later_button_area.containsMouse ?
                Qt.darker(palette.update_colour, 1.1) :
                palette.update_colour

                MouseArea {
                    id: later_button_area
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true
                    onClicked: {
                        app_state.updates_set_postpone();
                        loader_background_updates.source='';
                    }
                }

                Fonts.H2 {
                    anchors.centerIn: parent
                    color: "white"
                    text: qsTr("Later")
                }
            }
        }
    }
}
