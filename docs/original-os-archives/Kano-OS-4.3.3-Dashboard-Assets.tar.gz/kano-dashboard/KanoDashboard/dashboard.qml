/**
 * dashboard.qml
 *
 * Copyright (C) 2016 Kano Computing Ltd.
 * License: http://www.gnu.org/licenses/gpl-2.0.txt GNU GPL v2
 *
 * Main dashboard application
 */


import QtQuick 2.3
import QtQuick.Controls 1.4
import QtQuick.Controls.Styles 1.4
import QtGraphicalEffects 1.0
import QtMultimedia 5.5

import KanoDashboard 1.0 as KanoDashboard
import KanoDashboard.Views 1.0 as Views
import KanoDashboard.Widgets.Onboarding 1.0 as Onboarding
import KanoDashboard.Widgets.Templates 1.0 as Templates
import KanoDashboard.Widgets.Notifications 1.0 as Notifications
import KanoDashboard.Popups.SpeakerWarning 1.0 as SpeakerWarning

ApplicationWindow {
    id: main_window
    flags: Qt.FramelessWindowHint
    visible: true
    color: "transparent"

    visibility: "FullScreen"

    property var currentCursor: Qt.ArrowCursor

    onCurrentCursorChanged: {
        // change the shape as soon as possible
        main_cursor.cursorShape= main_window.currentCursor;
    }

    MouseArea {
        id: main_cursor
        anchors.fill: parent
        propagateComposedEvents: true
        cursorShape: currentCursor
        onClicked: {
            mouse.accepted = false
            app_state.global_click(mouse.x, mouse.y);
        }
    }

    Rectangle {
        id: app_wrapper
        width: parent.width
        height: parent.height
        color: 'transparent'
        focus: true

        states: [
            State {
                name: "shown"
                PropertyChanges {
                    target: main_window
                    currentCursor: Qt.ArrowCursor
                }
                PropertyChanges {
                    target: app_wrapper
                    opacity: 1.0
                    x: 0
                    y: 0
                }
            },
            State {
                name: "hidden"
                PropertyChanges {
                    target: main_window
                    currentCursor: Qt.BlankCursor
                }
                PropertyChanges {
                    target: app_wrapper
                    opacity: 0.0
                    x: 4000
                    y: 4000
                }
            },
            State {
                name: 'highlighting'
                extend: 'shown'
                PropertyChanges {
                    target: highlight
                    visible: true
                    state: 'shown'
                }
            }
        ]
        transitions: [
            Transition {
                NumberAnimation {
                    properties: "opacity"
                    duration: 100
                }
                NumberAnimation {
                    properties: "x, y"
                    duration: 0
                }
            },
            Transition {
                from: "shown"
                to: "hidden"
                SequentialAnimation {
                    NumberAnimation { properties: "opacity" }
                    NumberAnimation { properties: "x,y" }
                }
            },
            Transition {
                from: "hidden"
                to: "shown"
                SequentialAnimation {
                    NumberAnimation { properties: "x,y" }
                    NumberAnimation { properties: "opacity" }
                }
            }
        ]
        state: "shown"
        function show() {
            if (app_wrapper.state != "shown") {
                kano_profile.track_action(
                    'kanoDashboard-opened'
                )
                app_wrapper.state = "shown";
            }
        }
        function hide() {
            if (app_wrapper.state != "hidden") {
                app_wrapper.state = "hidden";
            }
        }

        function switch_view(view_name) {
            var view;
            switch(view_name) {
                case 'home':
                    view = home;
                    break;
                case 'profile':
                    view = profile;
                    break;
                default:
                    return;
            }

            viewLoader.sourceComponent = view
        }

        Rectangle {
            id: menu_container
            anchors.fill: parent
            color: "transparent"
            property alias menus: menu_container.data
            z: 100
        }

        SoundEffect {
            id: launch_sound
            source: "/usr/share/kano-dashboard/sounds/kano_open_app.wav"
            volume: kano_audio.volume
        }

        SoundEffect {
            id: hover_sound
            source: "/usr/share/kano-dashboard/sounds/move-cursor.wav"
            volume: kano_audio.volume
        }

        SoundEffect {
            id: click_sound
            source: "/usr/share/kano-dashboard/sounds/click.wav"
            volume: kano_audio.volume
        }

        Templates.OpenViewProcess {
            id: open_view_proc
        }

        Connections {
            target: app_state
            onFade_in: app_wrapper.show()
            onFade_out: app_wrapper.hide()
            onChange_view: app_wrapper.switch_view()
            onPlay_hover_sound: hover_sound.play()
            onPlay_click_sound: click_sound.play()
            onPlay_open_sound: launch_sound.play()
            onOpen_view: open_view_proc.run()
        }

        Binding {
            target: app_state
            property: 'global_scope'
            value: menu_container
        }

        Component.onCompleted: {
            console.log ("BackgroundUpdates: " + app_state.showBackgroundUpdates);
            console.log ("BootWarning: " + app_state.showBootWarning);
            console.log ("CKC?: " + app_state.is_KanoCKC);
            console.log ("UpgradeCommand: " + app_state.upgradeCommand);
            console.log ("showFeedbackWidget: " + app_state.showFeedbackWidget);

            /* popup the Background Updates dialog: inform user and kick install */
            if (app_state.showBootWarning) {
                if (app_state.is_KanoCKC) {
                    loader_boot_warning.source = "BootWarning/boot_warning_ckc.qml";
                }
                else {
                    loader_boot_warning.source = "BootWarning/boot_warning.qml";
                }
            } else if (app_state.showBackgroundUpdates) {
                loader_background_updates.source = "BackgroundUpdates/background_updates.qml";
            } else {
                /* popup the feedback widget if it's time, and logged in to KW */
                if (app_state.showFeedbackWidget) {
                    if (q_kano_world.is_registered()) {
                        console.log("Popping up the Feedback Widget");
                        loader_feedback_widget.source = "FeedbackWidget/feedback_widget.qml";
                    } else {
                        console.log("NOT Popping up Feedback Widget, user not registered");
                    }
                }
            }
        }

        Keys.onPressed: {
            if (!(event.modifiers & Qt.ShiftModifier)) {
                return false;
            }

            if (event.key == Qt.Key_Escape) {
                app_state.fade_out();
                return true;
            }

            if (event.key == Qt.Key_Backspace) {
                app_state.fade_in();
                return true;
            }
        }

        Image {
            id: background_img
            anchors.fill: parent
            verticalAlignment: Image.AlignBottom
            source: KanoDashboard.Wallpaper.get_system_wallpaper(settingsparser.value,
								 main_window.width, main_window.height)
            onStatusChanged: {
                if (status == Image.Error) {
                    source = 'wallpaper.png';
                }
            }
            fillMode: Image.Stretch
            clip: true
        }

        Views.ViewLoader {
            id: loader
        }

        Notifications.NotificationList {
            anchors.right: parent.right
        }

        Loader {
            id: loader_background_updates
            anchors.fill: parent
        }

        Loader {
            id: loader_boot_warning
            anchors.fill: parent
            z: 10
        }

        Loader {
            id: loader_feedback_widget
            anchors.fill: parent
        }

        /**
        * CKC v1.0 Speaker Warning
        *
        * Warning about the speaker on the CKC v1.0 and how to receive a free
        * upgrade.
        *
        * TODO: This can be removed as soon as we are confident that all
        *       affected customers have redeemed this offer
        */

        Component {
            id: speaker_warning
            SpeakerWarning.SpeakerWarning {
                onClaim: {
                    app_state.dismiss_speaker_warning();
                    open_view_proc.run(
                        'chromium-browser --app=http://kano.me/speaker --start-maximized'
                    )
                }
                onDismiss: app_state.dismiss_speaker_warning();
            }
        }

        Loader {
            id: loader_speaker_warning_widget
            anchors.fill: parent
            sourceComponent: app_state.show_speaker_warning ?
                speaker_warning : null
            z: 7
        }

    }
}
